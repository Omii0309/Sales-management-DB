/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dpm.dbapp;
import java.sql.*;

/**
 *
 * @author sspmcoe
 */
public class Mydb {
    Connection connection;
    PreparedStatement st;
    ResultSet rs1,rs2;
    
    Mydb()
    {
        try {       
             Class.forName("com.mysql.jdbc.Driver");
                    connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/Sale_DB",
                        "root", "");
               System.out.println("Connect");
            } catch (Exception e) {
                    System.out.println(e);
                }
            
    }
    public void insert(int Transaction_ID,String Product_name,String Person,String Mobile_number,int Quantity,int Total_cost)
    {
        try {
            st = (PreparedStatement) connection
                        .prepareStatement("INSERT INTO `Sales` (`Transaction_ID`, `Product_name`,`Person`, `Mobile_number`,`Quantity`, `Total_cost`) VALUES ('"+Transaction_ID + "', '" + Product_name + "','"+Person + "', '" + Mobile_number + "','"+Quantity + "', '" + Total_cost + "')");
            System.out.println(st.execute());
            /*if(st.execute())
            {
                System.out.print("Insert");
                //JOptionPane.showMessageDialog(Mydb, "You have successfully inserted");
            } else {
                        //JOptionPane.showMessageDialog(Mydb, "Wrong input");
                        System.out.print("Insert failed");
                    }*/
        }
        catch (SQLException sqlException) {
                    sqlException.printStackTrace();
                }
    }
    public static void main(String args[])
    {
        Mydb d =new Mydb();
        //d.insert(123, "pen","omkar","1234567890",10,100);
    }
    
}
